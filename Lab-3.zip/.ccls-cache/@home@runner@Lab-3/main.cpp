//Sevona Sims
//Sept 20,2022

#include <iostream>
using namespace std;
int main() 
{
  int num1;
  int num2;
  int sum;
  int counter;
  int diff;
  int prod;
  float quot;
  int mod;
  
   cout<<"Enter two integer values" << endl;
  cin>>num1>>num2;

  sum = num1 + num2;
  cout<< num1 << "+" << num2 << "is" << sum << endl;

  diff = num1 - num2;
  cout<< num1 <<"-" << num2 << "is" << diff << endl;

  prod =num1 * num2;
  cout<< num1<< "*" << num2 << "is" << prod << endl;

  quot = (float)num1 / num2;
  cout << num1 << "/" <<num2 << "is" << quot << endl;
  
  if (num2==0)
  {
    cout<< "cannot divide by zero!" << endl;
  }
  else

  counter = 1;
    cout<< " counter is " << counter << endl;

  counter = counter + 3;
  cout << " counter is " << counter << endl;

  counter+=2;
  cout << " counter is "<< counter << endl;

  counter++;
  cout<< " counter is " << counter << endl;

  mod = num1 % num2;
  cout << " mod is " << num1 << "%" << num2 << "remainder" << mod << endl;

  
  
    
  return 0;
}